<?php
    namespace Drupal\event\Plugin\rest\resource;
    use Drupal\Core\Session\AccountProxyInterface;
    use Drupal\node\Entity\Node;
    use Drupal\rest\ModifiedResourceResponse;
    use Drupal\rest\Plugin\ResourceBase;
    use Drupal\rest\ResourceResponse;
    use Psr\Log\LoggerInterface;
    use Symfony\Component\DependencyInjection\ContainerInterface;
    use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

	use Symfony\Component\HttpFoundation\Request;
	
	/**
     * Provides a resource to get view modes by entity and bundle.
     *
     * @RestResource(
     *   id = "event_resource",
     *   label = @Translation("event node rest resource"),
     *   serialization_class = "Drupal\node\Entity\Node",
     *   uri_paths = {
     *     "canonical" = "/event-node-rest",
     *     "https://www.drupal.org/link-relations/create" = "/event-node-rest"
     *   }
     * )
     */
    class EventResource extends ResourceBase {
 
      protected $currentUser;
	  protected $currentRequest;
      
      public function __construct(
        array $configuration,
        $plugin_id,
        $plugin_definition,
        array $serializer_formats,
        LoggerInterface $logger,
        AccountProxyInterface $current_user,
		Request $currentRequest
		) {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
 
        $this->currentUser = $current_user;
		$this->currentRequest = $currentRequest;
      }
 
      
      public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
        return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->getParameter('serializer.formats'),
          $container->get('logger.factory')->get('event'),
          $container->get('current_user'),
		  $container->get('request_stack')->getCurrentRequest()
        );
      }
 
      /**
       * Responds to POST requests.
       */
      public function post($node_data) {
        if ($this->currentUser->hasPermission('Event permission')) {        		
			
			if(!isset($node_data->type->target_id) || $node_data->type->target_id != 'event' 
				|| !isset($node_data->title->value)
				|| (isset($node_data->field_state->target_id) && !is_int($node_data->field_state->target_id)) 
				|| (isset($node_data->field_city->target_id) && !is_int($node_data->field_city->target_id))){
				return new ResourceResponse(array('Error'=>'Invalid data format'));
			}else {
				if($node_data->nid->value == ''){
					$node = Node::create(
					  array(
						'type' => $node_data->type->target_id,
						'title' => $node_data->title->value,				
						'field_state' => array(
							array( 'target_id' => $node_data->field_state->target_id )
						),
						'field_city' => array(
							array( 'target_id' => $node_data->field_city->target_id )
						),
						'field_event_date' => $node_data->field_event_date->value,
					  )
					);      
					$node->save();
				}
				elseif($node_data->nid->value != '' && is_int($node_data->nid->value)){
					$values = \Drupal::entityQuery('node')->condition('nid', $node_data->nid->value)->execute();
					$node_exists = !empty($values);
					if($node_exists){
						$node = Node::load($node_data->nid->value);
						$node->setTitle($node_data->title->value);                    
						$node->set('field_state', $node_data->field_state->target_id);
						$node->set('field_city', $node_data->field_city->target_id);
						$node->set('field_event_date', $node_data->field_event_date->value);
						$node->save();
					}else{
						\Drupal::logger('event_api')->error('Node nid '.$node_data->nid->value.' not exists' );
						return new ResourceResponse(array('Error'=>'Node nid not exists'));
					}       
				}
			}			           
			
		}else {
			throw new AccessDeniedHttpException();
		}
        return new ResourceResponse($node);
      }
       
         
     /**
       * Responds to GET requests.
       */
      public function get() {
        if ($this->currentUser->hasPermission('Event permission')) {
					
			$sql = db_select('node', 'n') 
				->fields('n', array('nid'));
				
			if($this->currentRequest->get('title')){
				$sql->leftJoin('node_field_data', 'nfd', 'n.nid = nfd.nid');
				$sql->condition('nfd.title', "%" .$this->currentRequest->get('title'). "%", 'LIKE');
			}
			if($this->currentRequest->get('field_state')){
				$sql->leftJoin('node__field_state', 'nfs', 'n.nid = nfs.entity_id');
				$sql->condition('nfs.field_state_target_id', $this->currentRequest->get('field_state'));
			}
			if($this->currentRequest->get('field_city')){
				$sql->leftJoin('node__field_city', 'nfc', 'n.nid = nfc.entity_id');			
				$sql->condition('nfc.field_city_target_id', $this->currentRequest->get('field_city'));
			}	
			
			$results = $sql->execute();
			
			
			foreach($results as $result){
				$node = Node::load($result->nid);
				$state = \Drupal\taxonomy\Entity\Term::load($node->field_state->target_id);
				$city = \Drupal\taxonomy\Entity\Term::load($node->field_city->target_id);
				$search_result[$result->nid] = array (
					'title' => $node->title->value,
					'State' => $state->name,
					'City' => $city->name,
					'Date' => $node->field_event_date->value,
				);
			}		
			
			$response = new ResourceResponse($search_result);
			$response->addCacheableDependency($search_result);
			return $response;
		
        }else {
			throw new AccessDeniedHttpException();
		}		
        
      }
	  
	  /**
       * Responds to DELETE requests.
       */
      public function delete($node_data) {
        if (!$this->currentUser->hasPermission('Event permission')) {
          throw new AccessDeniedHttpException();
        }
        if($node_data->nid->value != '' && is_int($node_data->nid->value)){
			$node = Node::load($node_data->nid->value);
			if ($node) {
			  $node->delete();
			}
		}else {
			return new ResourceResponse(array('Error'=>'Node nid not exists'));
		}
        $response = new ResourceResponse($result);
        $response->addCacheableDependency($result);
        return $response;
      }
 
    }